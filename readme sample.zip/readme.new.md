# ReadMe Generator ![Static Badge](https://img.shields.io/badge/license-MIT-blue)

## Description

This will generate a readme based on users response

## Table of Contents
* [Installation](#installation)
* [Usage](#usage)
* [Contributing](#contributing)
* [Tests](#tests)
* [License](#license)
* [Questions](#questions)

## Installation

Run 'npm install' in terminal to install dependencies 

## Usage

Answer all prompts accordingly 

## Contributing

There are no contribution guidelines

## Tests

There are no tests for this project

## License 

This project is covered under the MIT License. For more information about license go to [https://mit-license.org/](https://mit-license.org/)

## Questions

If there are additional questions, you may contact me at jorgecastro619@gmail.com or visit my [GitHub](https://github.com/Jacastro619)
